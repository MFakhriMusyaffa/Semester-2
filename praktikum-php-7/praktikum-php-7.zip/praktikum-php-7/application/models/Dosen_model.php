<?php
    class Dosen_model extends CI_Model {
        public $id;
        public $nama;
        public $nidn;
        public $gender;
        public $pendidikan;
}
?>